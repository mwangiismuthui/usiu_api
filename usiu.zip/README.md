

## About Usiu Connect 

Social platform developed for the United States International Universty that is aimed at enhancing greater collaboration in the University ecosystem among Lectures and Students and among peer students 

